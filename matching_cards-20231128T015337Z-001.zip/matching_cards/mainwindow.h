#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QGraphicsPixmapItem>
#include <QGraphicsView>
#include <QGridLayout>




namespace Ui {
class MainWindow;
}

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void setButtonImage(QPushButton *button, const QString &imagePath);
    void moveButton(QPushButton *button, int deltaX, int deltaY);
    void keyPressEvent(QKeyEvent *event);
    QGraphicsView *graphicsView;
    QGridLayout *buttonLayout;


    static const int ROWS = 6;
    static const int COLS = 6;


public slots:
    void revealSecondSet();



private:
    Ui::MainWindow *ui;
    QGraphicsPixmapItem backcards2[ROWS][COLS];
    QPushButton *pushButton_37;
    bool secondSetRevealed;
     bool sKeyPressed;
    int step = 10;


};
#endif // MAINWINDOW_H
