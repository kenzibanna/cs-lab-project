#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPushButton>
#include <QToolButton>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include <QGraphicsView>
#include <QVBoxLayout>
#include <QGraphicsScene>
#include <QGridLayout>




MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)

{

    ui->setupUi(this);

   setButtonImage(ui->pushButton, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_2, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_3, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_4, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_5, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_6, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_7, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_8, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_9, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_10, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_11, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_12, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_13, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_14, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_15, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_16, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_17, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_18, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_19, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_20, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_21, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_22, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_23, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_24, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_25, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_26, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_27, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_28, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_29, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_30, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_31, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_32, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_33, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_34, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_35, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_36, ":/new/images/cardback.png");
    setButtonImage(ui->pushButton_37, ":/new/images/clicker.png");



    pushButton_37 = ui->pushButton_37;

    pushButton_37->setFocusPolicy(Qt::StrongFocus);

    setButtonImage(ui->pushButton_37, ":/new/images/clicker.png");

    secondSetRevealed = false;
    sKeyPressed = false;

    QGraphicsScene *scene = new QGraphicsScene(this);
 //   ui->graphicsView->setScene(scene);

    QGraphicsPixmapItem *clickerItem = new QGraphicsPixmapItem(QPixmap(":/new/images/clicker.png"));
    scene->addItem(clickerItem);

   // clickerItem->setPos(0, 0);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::setButtonImage(QPushButton *button, const QString &imagePath)
{
    QPixmap pixmap(imagePath);

    int maxWidth = 70;
    int maxHeight = 100;

    QPixmap scaledPixmap = pixmap.scaled(maxWidth, maxHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);

    button->setFixedSize(scaledPixmap.size());
    button->setIcon(QIcon(scaledPixmap));
    button->setIconSize(scaledPixmap.size());
}



void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_S:
        revealSecondSet();
        break;
  /*  case Qt::Key_Left:
        moveButton(-step, 0);
        break;
    case Qt::Key_Right:
        moveButton(step, 0);
        break;
    case Qt::Key_Up:
        moveButton(0, -step);
        break;
    case Qt::Key_Down:
        moveButton(0, step);
        break;*/
    default:
        QMainWindow::keyPressEvent(event);
    }


}

void MainWindow::revealSecondSet()
{
    if (!secondSetRevealed)
    {
        setButtonImage(ui->pushButton, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_2, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_3, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_4, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_5, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_6, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_7, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_8, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_9, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_10, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_11, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_12, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_13, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_14, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_15, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_16, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_17, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_18, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_19, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_20, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_21, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_22, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_23, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_24, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_25, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_26, ":/new/images/heart.png");
        setButtonImage(ui->pushButton_27, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_28, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_29, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_30, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_31, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_32, ":/new/images/clubs.png");
        setButtonImage(ui->pushButton_33, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_34, ":/new/images/diamonds.png");
        setButtonImage(ui->pushButton_35, ":/new/images/spade.png");
        setButtonImage(ui->pushButton_36, ":/new/images/diamonds.png");
        secondSetRevealed = true;
        qDebug() << "Second set revealed!";
    }
    else
    {
        setButtonImage(ui->pushButton, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_2, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_3, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_4, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_5, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_6, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_7, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_8, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_9, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_10, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_11, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_12, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_13, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_14, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_15, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_16, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_17, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_18, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_19, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_20, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_21, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_22, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_23, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_24, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_25, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_26, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_27, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_28, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_29, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_30, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_31, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_32, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_33, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_34, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_35, ":/new/images/cardback.png");
        setButtonImage(ui->pushButton_36, ":/new/images/cardback.png");
        secondSetRevealed = false;
        qDebug() << "Second set hidden!";
    }
}

/*void MainWindow::moveButton(int deltaX, int deltaY)
{
    // Get the current position of the clickerItem
    QPointF currentPosition = ui->graphicsView->mapToScene(ui->pushButton_37->pos());

    // Update the position
    QPointF newPosition = currentPosition + QPointF(deltaX, deltaY);

    // Set the new position using setPos on the QGraphicsPixmapItem
    ui->graphicsView->scene()->items().at(0)->setPos(newPosition);
}*/
